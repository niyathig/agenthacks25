import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';

import LandingPage from './components/landing/LandingPage';
import IntakeForm from './components/intake/IntakeForm';
import ConfirmationPage from './components/confirmation/ConfirmationPage';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      <AnimatePresence mode="wait">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/intake" element={<IntakeForm />} />
          <Route path="/confirmation" element={<ConfirmationPage />} />
        </Routes>
      </AnimatePresence>
    </div>
  );
}

export default App;