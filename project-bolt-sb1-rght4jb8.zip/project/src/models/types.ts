export interface UserData {
  fullName: string;
  phoneNumber: string;
  linkedin?: string;
  role: string;
  company: string;
  jobPostingLink?: string;
  interviewStage: string;
  interviewDate: string;
  interviewerName?: string;
}

export type InterviewStage = 
  | 'Phone Screen'
  | 'Technical Interview'
  | 'Behavioral Interview'
  | 'Case Interview'
  | 'Panel Interview'
  | 'Final Round';