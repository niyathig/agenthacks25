import React from 'react';
import { motion } from 'framer-motion';
import { PhoneCall, CheckCircle, ArrowUpRight } from 'lucide-react';
import Header from '../ui/Header';
import Footer from '../ui/Footer';

const ConfirmationPage: React.FC = () => {
  const phoneNumber = "620-312-8277";
  const formattedPhoneNumber = phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3");
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gradient-to-br from-primary-50 to-white py-12">
        <div className="container-custom max-w-3xl">
          <motion.div 
            className="card text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
            </div>
            
            <h1 className="text-3xl font-bold mb-2">You're All Set!</h1>
            <p className="text-gray-600 mb-8 text-lg">
              You're one step closer to landing your dream job!
            </p>
            
            <div className="bg-primary-50 rounded-xl p-6 mb-8">
              <p className="text-lg mb-4">Call this number to start your mock interview:</p>
              <motion.div 
                className="text-4xl md:text-5xl font-bold text-primary-600 mb-4"
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                transition={{ 
                  yoyo: Infinity, 
                  duration: 2,
                  ease: "easeInOut" 
                }}
              >
                {formattedPhoneNumber}
              </motion.div>
              
              <a 
                href={`tel:${phoneNumber.replace(/-/g, '')}`}
                className="btn-primary inline-flex items-center text-lg"
              >
                <PhoneCall className="mr-2 h-5 w-5" />
                Call Now
              </a>
            </div>
            
            <div className="border-t border-gray-200 pt-6">
              <h2 className="text-xl font-semibold mb-4">What Happens Next?</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {[
                  {
                    title: "Call the Number",
                    description: "Our automated system will answer and begin the interview process."
                  },
                  {
                    title: "Answer the Question",
                    description: "You'll be asked a relevant interview question based on your profile."
                  },
                  {
                    title: "Receive Feedback",
                    description: "Get personalized feedback to improve your interview skills."
                  }
                ].map((step, index) => (
                  <div key={index} className="p-4 bg-gray-50 rounded-lg">
                    <div className="font-semibold mb-1">{index + 1}. {step.title}</div>
                    <p className="text-sm text-gray-600">{step.description}</p>
                  </div>
                ))}
              </div>
              
              <div className="bg-accent-50 rounded-lg p-4 text-accent-800 text-sm mb-6">
                <p>💡 <strong>Pro Tip:</strong> Find a quiet space where you won't be interrupted for about 10 minutes to complete your mock interview.</p>
              </div>
              
              <motion.div 
                className="bg-primary-600 text-white p-6 rounded-lg"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <h3 className="text-xl font-semibold mb-2">Ready to Crush Your Interview?</h3>
                <p className="mb-4">Call now and practice with a real interview question!</p>
                <a 
                  href={`tel:${phoneNumber.replace(/-/g, '')}`}
                  className="inline-flex items-center bg-white text-primary-600 px-6 py-3 rounded-lg font-medium hover:bg-primary-50 transition-colors"
                >
                  <PhoneCall className="mr-2 h-5 w-5" />
                  {phoneNumber}
                  <ArrowUpRight className="ml-2 h-4 w-4" />
                </a>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ConfirmationPage;