import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '../ui/Header';
import Footer from '../ui/Footer';
import { ArrowRight } from 'lucide-react';

interface FormData {
  fullName: string;
  phoneNumber: string;
  linkedin: string;
  role: string;
  company: string;
  jobPostingLink: string;
  interviewStage: string;
  interviewDate: string;
  interviewerName: string;
}

const IntakeForm: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    phoneNumber: '',
    linkedin: '',
    role: '',
    company: '',
    jobPostingLink: '',
    interviewStage: '',
    interviewDate: '',
    interviewerName: ''
  });
  
  const [errors, setErrors] = useState<Partial<FormData>>({});
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user types
    if (errors[name as keyof FormData]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Partial<FormData> = {};
    
    if (!formData.fullName.trim()) newErrors.fullName = 'Name is required';
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phoneNumber.replace(/\D/g, ''))) {
      newErrors.phoneNumber = 'Please enter a valid 10-digit phone number';
    }
    if (!formData.role.trim()) newErrors.role = 'Role is required';
    if (!formData.company.trim()) newErrors.company = 'Company is required';
    if (!formData.interviewStage) newErrors.interviewStage = 'Interview stage is required';
    if (!formData.interviewDate) newErrors.interviewDate = 'Interview date is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // In a real app, we would submit to backend here
      // Since this is frontend only, we'll just navigate to confirmation
      navigate('/confirmation');
    }
  };
  
  const interviewStages = [
    'Phone Screen',
    'Technical Interview',
    'Behavioral Interview',
    'Case Interview',
    'Panel Interview',
    'Final Round'
  ];
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-12">
        <div className="container-custom max-w-3xl">
          <motion.div 
            className="card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-2">Tell Us About Your Interview</h1>
              <p className="text-gray-600">
                We'll use this information to tailor your mock interview experience.
              </p>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Personal Information */}
                <div className="md:col-span-2">
                  <h2 className="text-xl font-semibold mb-4 border-b pb-2">Personal Information</h2>
                </div>
                
                <div className="form-group">
                  <label htmlFor="fullName" className="form-label">Full Name <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    className={`input-field ${errors.fullName ? 'border-red-500' : ''}`}
                    value={formData.fullName}
                    onChange={handleChange}
                    placeholder="John Doe"
                  />
                  {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="phoneNumber" className="form-label">Phone Number <span className="text-red-500">*</span></label>
                  <input
                    type="tel"
                    id="phoneNumber"
                    name="phoneNumber"
                    className={`input-field ${errors.phoneNumber ? 'border-red-500' : ''}`}
                    value={formData.phoneNumber}
                    onChange={handleChange}
                    placeholder="(555) 123-4567"
                  />
                  {errors.phoneNumber && <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>}
                </div>
                
                <div className="form-group md:col-span-2">
                  <label htmlFor="linkedin" className="form-label">LinkedIn Profile (optional)</label>
                  <input
                    type="text"
                    id="linkedin"
                    name="linkedin"
                    className="input-field"
                    value={formData.linkedin}
                    onChange={handleChange}
                    placeholder="linkedin.com/in/yourprofile"
                  />
                </div>
                
                {/* Job Information */}
                <div className="md:col-span-2 mt-4">
                  <h2 className="text-xl font-semibold mb-4 border-b pb-2">Job Information</h2>
                </div>
                
                <div className="form-group">
                  <label htmlFor="role" className="form-label">Role You're Applying For <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    id="role"
                    name="role"
                    className={`input-field ${errors.role ? 'border-red-500' : ''}`}
                    value={formData.role}
                    onChange={handleChange}
                    placeholder="Software Engineer"
                  />
                  {errors.role && <p className="text-red-500 text-sm mt-1">{errors.role}</p>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="company" className="form-label">Company <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    className={`input-field ${errors.company ? 'border-red-500' : ''}`}
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Acme Inc."
                  />
                  {errors.company && <p className="text-red-500 text-sm mt-1">{errors.company}</p>}
                </div>
                
                <div className="form-group md:col-span-2">
                  <label htmlFor="jobPostingLink" className="form-label">Job Posting Link (optional)</label>
                  <input
                    type="text"
                    id="jobPostingLink"
                    name="jobPostingLink"
                    className="input-field"
                    value={formData.jobPostingLink}
                    onChange={handleChange}
                    placeholder="https://company.com/jobs/position"
                  />
                </div>
                
                {/* Interview Information */}
                <div className="md:col-span-2 mt-4">
                  <h2 className="text-xl font-semibold mb-4 border-b pb-2">Interview Information</h2>
                </div>
                
                <div className="form-group">
                  <label htmlFor="interviewStage" className="form-label">Interview Stage <span className="text-red-500">*</span></label>
                  <select
                    id="interviewStage"
                    name="interviewStage"
                    className={`input-field ${errors.interviewStage ? 'border-red-500' : ''}`}
                    value={formData.interviewStage}
                    onChange={handleChange}
                  >
                    <option value="">Select Interview Stage</option>
                    {interviewStages.map((stage) => (
                      <option key={stage} value={stage}>{stage}</option>
                    ))}
                  </select>
                  {errors.interviewStage && <p className="text-red-500 text-sm mt-1">{errors.interviewStage}</p>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="interviewDate" className="form-label">Interview Date <span className="text-red-500">*</span></label>
                  <input
                    type="date"
                    id="interviewDate"
                    name="interviewDate"
                    className={`input-field ${errors.interviewDate ? 'border-red-500' : ''}`}
                    value={formData.interviewDate}
                    onChange={handleChange}
                    min={new Date().toISOString().split('T')[0]}
                  />
                  {errors.interviewDate && <p className="text-red-500 text-sm mt-1">{errors.interviewDate}</p>}
                </div>
                
                <div className="form-group md:col-span-2">
                  <label htmlFor="interviewerName" className="form-label">Interviewer Name (if known)</label>
                  <input
                    type="text"
                    id="interviewerName"
                    name="interviewerName"
                    className="input-field"
                    value={formData.interviewerName}
                    onChange={handleChange}
                    placeholder="Jane Smith"
                  />
                </div>
              </div>
              
              <div className="mt-8 text-center">
                <motion.button
                  type="submit"
                  className="btn-primary px-8 py-4 text-lg flex items-center justify-center mx-auto"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Continue to Mock Interview
                  <ArrowRight className="ml-2 h-5 w-5" />
                </motion.button>
              </div>
            </form>
          </motion.div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default IntakeForm;