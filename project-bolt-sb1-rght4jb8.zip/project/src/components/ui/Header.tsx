import React from 'react';
import { Link } from 'react-router-dom';
import { Headphones } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm py-4">
      <div className="container-custom">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <Headphones className="h-8 w-8 text-primary-600 mr-2" />
            <span className="text-xl font-bold text-primary-600">PrepWise</span>
          </Link>
          
          <nav>
            <Link to="/intake">
              <button className="btn-secondary">
                Get Started
              </button>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;