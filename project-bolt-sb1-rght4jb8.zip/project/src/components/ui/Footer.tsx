import React from 'react';
import { Link } from 'react-router-dom';
import { Headphones, Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-4">
              <Headphones className="h-8 w-8 text-primary-400 mr-2" />
              <span className="text-xl font-bold text-white">PrepWise</span>
            </div>
            <p className="text-gray-400 mb-4">
              Helping you ace your interviews with real practice and expert feedback.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/intake" className="text-gray-400 hover:text-white transition-colors">Get Started</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <p className="text-gray-400">
              Have questions? Email us at:<br />
              <a href="mailto:hello@prepwise.com" className="text-primary-400 hover:text-primary-300 transition-colors">
                hello@prepwise.com
              </a>
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} PrepWise. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;