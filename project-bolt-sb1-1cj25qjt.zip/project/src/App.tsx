import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { SupabaseProvider } from './contexts/SupabaseContext';
import Layout from './components/layout/Layout';
import Home from './pages/Home';
import IntakeForm from './pages/IntakeForm';
import FeedbackPage from './pages/FeedbackPage';
import DebriefPage from './pages/DebriefPage';
import NotFound from './pages/NotFound';

function App() {
  return (
    <SupabaseProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/intake" element={<IntakeForm />} />
            <Route path="/feedback/:id" element={<FeedbackPage />} />
            <Route path="/debrief/:id" element={<DebriefPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      </Router>
    </SupabaseProvider>
  );
}

export default App;