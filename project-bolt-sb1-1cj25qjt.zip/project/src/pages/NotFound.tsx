import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home } from 'lucide-react';
import Button from '../components/ui/Button';

const NotFound: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="container-md text-center py-16">
      <div className="card max-w-md mx-auto">
        <h1 className="text-6xl font-bold text-gray-200 mb-4">404</h1>
        <h2 className="text-2xl font-semibold mb-2">Page Not Found</h2>
        <p className="text-gray-600 mb-6">
          Sorry, the page you're looking for doesn't exist or has been moved.
        </p>
        <Button 
          variant="primary" 
          onClick={() => navigate('/')}
          leftIcon={<Home className="h-5 w-5" />}
        >
          Return Home
        </Button>
      </div>
    </div>
  );
};

export default NotFound;