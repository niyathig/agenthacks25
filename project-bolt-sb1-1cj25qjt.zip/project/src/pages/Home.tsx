import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Book, Phone, BarChart4 } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="container-lg">
      <section className="text-center mb-16 animate-fadeIn">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Master Your Job Interviews with <span className="text-primary-600">PrepWise</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
          AI-powered mock interviews and personalized feedback to help you land your dream job
        </p>
        <Link
          to="/intake"
          className="btn btn-primary px-6 py-3 text-lg inline-flex items-center"
        >
          <Sparkles className="h-5 w-5 mr-2" />
          Start Your Prep
        </Link>
      </section>

      <section className="grid md:grid-cols-3 gap-8 mb-16">
        {features.map((feature, index) => (
          <div 
            key={index} 
            className="card hover:shadow-lg transition-shadow" 
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="mb-4">
              <feature.icon className="h-10 w-10 text-primary-500" />
            </div>
            <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-gray-600">{feature.description}</p>
          </div>
        ))}
      </section>

      <section className="card mb-16">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">How It Works</h2>
          <p className="text-gray-600">Simple steps to interview success</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary-100 text-primary-600 text-xl font-bold mb-4">
                {index + 1}
              </div>
              <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="text-center mb-16">
        <h2 className="text-3xl font-bold mb-6">Ready to ace your interview?</h2>
        <Link
          to="/intake"
          className="btn btn-primary px-6 py-3 text-lg"
        >
          Get Started Now
        </Link>
      </section>
    </div>
  );
};

const features = [
  {
    icon: Phone,
    title: "Realistic Phone Interviews",
    description: "Practice with simulated phone interviews that mirror real-world scenarios and questions."
  },
  {
    icon: BarChart4,
    title: "AI-Powered Feedback",
    description: "Receive detailed analysis on your clarity, specificity, and confidence in answering questions."
  },
  {
    icon: Book,
    title: "Post-Interview Learning",
    description: "Track your progress and learn from actual interview experiences to continuously improve."
  }
];

const steps = [
  {
    title: "Complete the Intake Form",
    description: "Provide details about the job, company, and upcoming interview."
  },
  {
    title: "Participate in a Mock Interview",
    description: "Receive a phone call with a job-specific interview question to answer."
  },
  {
    title: "Review Your Detailed Feedback",
    description: "Get AI analysis of your performance with specific improvement suggestions."
  }
];

export default Home;