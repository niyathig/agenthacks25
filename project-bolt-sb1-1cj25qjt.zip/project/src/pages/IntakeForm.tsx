import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm, SubmitHandler } from 'react-hook-form';
import { format } from 'date-fns';
import { CalendarClock, Briefcase, Building, Phone } from 'lucide-react';
import { useSupabase } from '../contexts/SupabaseContext';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import { initiateInterview } from '../services/interviewService';

type IntakeFormInputs = {
  fullName: string;
  phoneNumber: string;
  linkedinUrl: string;
  role: string;
  company: string;
  jobPostingUrl: string;
  interviewStage: string;
  interviewDate: string;
  interviewerName: string;
};

const interviewStageOptions = [
  { value: 'phone_screen', label: 'Phone Screen' },
  { value: 'technical', label: 'Technical Interview' },
  { value: 'behavioral', label: 'Behavioral Interview' },
  { value: 'hiring_manager', label: 'Hiring Manager Interview' },
  { value: 'final', label: 'Final Round' },
];

const IntakeForm: React.FC = () => {
  const navigate = useNavigate();
  const { supabase } = useSupabase();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IntakeFormInputs>({
    defaultValues: {
      interviewDate: format(new Date(), 'yyyy-MM-dd'),
    }
  });

  const onSubmit: SubmitHandler<IntakeFormInputs> = async (data) => {
    try {
      setIsSubmitting(true);
      
      // Insert interview data to Supabase
      const { data: interview, error } = await supabase
        .from('interviews')
        .insert({
          full_name: data.fullName,
          phone_number: data.phoneNumber,
          linkedin_url: data.linkedinUrl || null,
          role: data.role,
          company: data.company,
          job_posting_url: data.jobPostingUrl,
          interview_stage: data.interviewStage,
          interview_date: data.interviewDate,
          interviewer_name: data.interviewerName || null,
          status: 'pending',
        })
        .select()
        .single();
      
      if (error) {
        throw error;
      }
      
      // Initiate interview call
      await initiateInterview({
        interviewId: interview.id,
        phoneNumber: data.phoneNumber,
        role: data.role,
        company: data.company,
      });
      
      navigate(`/feedback/${interview.id}`);
    } catch (error) {
      console.error('Error submitting form:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container-md">
      <div className="card max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Schedule Your Mock Interview</h1>
          <p className="text-gray-600">Fill in the details below to prepare for your upcoming interview</p>
        </div>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Input
                label="Full Name"
                {...register('fullName', { required: 'Name is required' })}
                error={errors.fullName?.message}
                placeholder="Jane Doe"
              />
            </div>
            
            <div>
              <Input
                label="Phone Number"
                type="tel"
                {...register('phoneNumber', { 
                  required: 'Phone number is required',
                  pattern: {
                    value: /^\+?[1-9]\d{1,14}$/,
                    message: 'Please enter a valid phone number'
                  }
                })}
                error={errors.phoneNumber?.message}
                placeholder="+1 123 456 7890"
                helpText="We'll call you at this number for your mock interview"
              />
            </div>
          </div>
          
          <Input
            label="LinkedIn URL (Optional)"
            type="url"
            {...register('linkedinUrl')}
            placeholder="https://linkedin.com/in/yourusername"
          />
          
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Input
                label="Role"
                {...register('role', { required: 'Role is required' })}
                error={errors.role?.message}
                placeholder="Software Engineer"
                leftIcon={<Briefcase className="h-4 w-4 text-gray-400" />}
              />
            </div>
            
            <div>
              <Input
                label="Company"
                {...register('company', { required: 'Company is required' })}
                error={errors.company?.message}
                placeholder="Acme Inc"
                leftIcon={<Building className="h-4 w-4 text-gray-400" />}
              />
            </div>
          </div>
          
          <Input
            label="Job Posting URL"
            type="url"
            {...register('jobPostingUrl', { required: 'Job posting URL is required' })}
            error={errors.jobPostingUrl?.message}
            placeholder="https://company.com/careers/job-posting"
          />
          
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Select
                label="Interview Stage"
                options={interviewStageOptions}
                {...register('interviewStage', { required: 'Interview stage is required' })}
                error={errors.interviewStage?.message}
              />
            </div>
            
            <div>
              <Input
                label="Interview Date"
                type="date"
                {...register('interviewDate', { required: 'Interview date is required' })}
                error={errors.interviewDate?.message}
                min={format(new Date(), 'yyyy-MM-dd')}
                leftIcon={<CalendarClock className="h-4 w-4 text-gray-400" />}
              />
            </div>
          </div>
          
          <Input
            label="Interviewer Name (Optional)"
            {...register('interviewerName')}
            placeholder="John Smith"
          />
          
          <div className="flex justify-end mt-6">
            <Button
              type="submit"
              variant="primary"
              size="lg"
              isLoading={isSubmitting}
              leftIcon={<Phone className="h-5 w-5" />}
            >
              Schedule Mock Interview
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default IntakeForm;