import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm, SubmitHandler } from 'react-hook-form';
import { CheckCircle, Star, PlusCircle, MinusCircle, Home } from 'lucide-react';
import { useSupabase } from '../contexts/SupabaseContext';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';

type DebriefFormInputs = {
  rating: number;
  questions: string[];
  notes: string;
};

const DebriefPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { supabase } = useSupabase();
  
  const [interview, setInterview] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [questions, setQuestions] = useState<string[]>(['']);
  
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<DebriefFormInputs>({
    defaultValues: {
      rating: 3,
      questions: [''],
      notes: '',
    }
  });
  
  useEffect(() => {
    const fetchInterview = async () => {
      try {
        if (!id) return;
        
        const { data, error } = await supabase
          .from('interviews')
          .select('*')
          .eq('id', id)
          .single();
          
        if (error) {
          throw error;
        }
        
        setInterview(data);
      } catch (err) {
        console.error('Error fetching interview:', err);
        setError('Failed to load interview data. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchInterview();
  }, [id, supabase]);
  
  const onSubmit: SubmitHandler<DebriefFormInputs> = async (data) => {
    try {
      setIsSubmitting(true);
      
      // Filter out empty questions
      const filteredQuestions = questions.filter(q => q.trim() !== '');
      
      const { error } = await supabase
        .from('debriefs')
        .insert({
          interview_id: id!,
          rating: data.rating,
          actual_questions: filteredQuestions,
          notes: data.notes || null,
        });
        
      if (error) {
        throw error;
      }
      
      setSuccess(true);
    } catch (err) {
      console.error('Error submitting debrief:', err);
      setError('Failed to submit debrief. Please try again later.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleAddQuestion = () => {
    setQuestions([...questions, '']);
  };
  
  const handleRemoveQuestion = (index: number) => {
    const updatedQuestions = [...questions];
    updatedQuestions.splice(index, 1);
    setQuestions(updatedQuestions);
  };
  
  const handleQuestionChange = (index: number, value: string) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index] = value;
    setQuestions(updatedQuestions);
  };
  
  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`w-8 h-8 cursor-pointer ${i <= Number(interview?.rating || 0) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
          onClick={() => setValue('rating', i)}
        />
      );
    }
    return stars;
  };
  
  if (isLoading) {
    return (
      <div className="container-md text-center py-16">
        <div className="animate-pulse">
          <h2 className="text-2xl font-semibold mb-2">Loading...</h2>
          <p className="text-gray-600">Retrieving your interview details</p>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="container-md text-center py-16">
        <h2 className="text-2xl font-semibold mb-2 text-error-600">Error</h2>
        <p className="text-gray-600 mb-4">{error}</p>
        <Button variant="primary" onClick={() => navigate('/')}>
          Go Back Home
        </Button>
      </div>
    );
  }

  if (success) {
    return (
      <div className="container-md text-center py-16 animate-fadeIn">
        <CheckCircle className="w-16 h-16 text-success-500 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Thank You!</h2>
        <p className="text-gray-600 mb-8">
          Your post-interview debrief has been successfully submitted. This information helps us improve our interview preparation tools.
        </p>
        <Button 
          variant="primary" 
          onClick={() => navigate('/')}
          leftIcon={<Home className="h-5 w-5" />}
        >
          Return Home
        </Button>
      </div>
    );
  }

  return (
    <div className="container-md">
      <div className="card">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Post-Interview Debrief</h1>
          <p className="text-gray-600">
            Let us know how your real interview for {interview?.role} at {interview?.company} went
          </p>
        </div>
        
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="mb-6">
            <label className="form-label">How would you rate the real interview experience?</label>
            <div className="flex items-center space-x-2 mt-2">
              {renderStars()}
            </div>
            {errors.rating && <p className="form-error">{errors.rating.message}</p>}
          </div>
          
          <div className="mb-6">
            <label className="form-label mb-2">What questions were you actually asked?</label>
            {questions.map((question, index) => (
              <div key={index} className="flex mb-2">
                <Input
                  value={question}
                  onChange={(e) => handleQuestionChange(index, e.target.value)}
                  placeholder="Enter interview question"
                  className="flex-grow"
                />
                {index === 0 ? (
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={handleAddQuestion}
                    className="ml-2"
                  >
                    <PlusCircle className="h-5 w-5 text-primary-500" />
                  </Button>
                ) : (
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => handleRemoveQuestion(index)}
                    className="ml-2"
                  >
                    <MinusCircle className="h-5 w-5 text-error-500" />
                  </Button>
                )}
              </div>
            ))}
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={handleAddQuestion}
              leftIcon={<PlusCircle className="h-4 w-4" />}
              className="mt-2"
            >
              Add Another Question
            </Button>
          </div>
          
          <Textarea
            label="Additional Notes (Optional)"
            {...register('notes')}
            placeholder="Any other feedback or observations about the interview process..."
          />
          
          <div className="flex justify-end mt-6">
            <Button
              type="submit"
              variant="primary"
              size="lg"
              isLoading={isSubmitting}
            >
              Submit Debrief
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DebriefPage;