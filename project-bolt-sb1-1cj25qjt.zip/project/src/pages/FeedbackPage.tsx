import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  MessageSquare, BarChart, Check, AlertCircle, Clock, Award, BookOpenCheck
} from 'lucide-react';
import { useSupabase } from '../contexts/SupabaseContext';
import Button from '../components/ui/Button';
import { generateFeedback } from '../services/interviewService';

interface FeedbackScore {
  score: number;
  summary: string;
  suggestions: string[];
}

interface FeedbackData {
  clarity: FeedbackScore;
  specificity: FeedbackScore;
  confidence: FeedbackScore;
  overall: {
    score: number;
    summary: string;
  };
}

const FeedbackPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { supabase } = useSupabase();
  
  const [interview, setInterview] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchInterview = async () => {
      try {
        if (!id) return;
        
        const { data, error } = await supabase
          .from('interviews')
          .select('*')
          .eq('id', id)
          .single();
          
        if (error) {
          throw error;
        }
        
        setInterview(data);
        
        // If we have a transcript but no feedback, automatically generate feedback
        if (data.transcript && !data.feedback) {
          handleGenerateFeedback();
        }
      } catch (err) {
        console.error('Error fetching interview:', err);
        setError('Failed to load interview data. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchInterview();
  }, [id, supabase]);
  
  const handleGenerateFeedback = async () => {
    try {
      if (!interview?.transcript) {
        setError('No transcript available to generate feedback.');
        return;
      }
      
      setIsGeneratingFeedback(true);
      
      const feedback = await generateFeedback(interview.id, interview.transcript);
      
      setInterview({ ...interview, feedback });
    } catch (err) {
      console.error('Error generating feedback:', err);
      setError('Failed to generate feedback. Please try again later.');
    } finally {
      setIsGeneratingFeedback(false);
    }
  };

  const handleGoToDebrief = () => {
    navigate(`/debrief/${interview.id}`);
  };
  
  if (isLoading) {
    return (
      <div className="container-md text-center py-16">
        <Clock className="w-12 h-12 text-primary-500 mx-auto animate-pulse" />
        <h2 className="text-2xl font-semibold mt-4 mb-2">Loading interview data...</h2>
        <p className="text-gray-600">This won't take long.</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="container-md text-center py-16">
        <AlertCircle className="w-12 h-12 text-error-500 mx-auto" />
        <h2 className="text-2xl font-semibold mt-4 mb-2">Something went wrong</h2>
        <p className="text-gray-600 mb-4">{error}</p>
        <Button variant="primary" onClick={() => navigate('/')}>
          Go Back Home
        </Button>
      </div>
    );
  }
  
  if (!interview?.transcript) {
    return (
      <div className="container-md text-center py-16">
        <Clock className="w-12 h-12 text-primary-500 mx-auto" />
        <h2 className="text-2xl font-semibold mt-4 mb-2">Interview in Progress</h2>
        <p className="text-gray-600 mb-4">
          Your mock interview call is being processed. Please wait while we analyze your responses.
        </p>
        <Button variant="secondary" onClick={() => window.location.reload()}>
          Refresh Status
        </Button>
      </div>
    );
  }

  const feedbackData = interview.feedback as FeedbackData;

  return (
    <div className="container-md">
      <div className="card mb-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Your Interview Feedback</h1>
          <p className="text-gray-600">
            {interview.role} at {interview.company}
          </p>
        </div>

        {!feedbackData && !isGeneratingFeedback && (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 text-primary-500 mx-auto" />
            <h2 className="text-xl font-semibold mt-4 mb-2">Ready to Generate Feedback</h2>
            <p className="text-gray-600 mb-4">
              Your interview transcript is ready. Click below to analyze your responses.
            </p>
            <Button 
              variant="primary" 
              onClick={handleGenerateFeedback}
              leftIcon={<BarChart className="h-5 w-5" />}
            >
              Generate Feedback
            </Button>
          </div>
        )}

        {isGeneratingFeedback && (
          <div className="text-center py-8">
            <div className="animate-pulse">
              <BarChart className="w-12 h-12 text-primary-500 mx-auto" />
              <h2 className="text-xl font-semibold mt-4 mb-2">Generating Your Feedback</h2>
              <p className="text-gray-600">
                Our AI is analyzing your interview responses. This will take just a moment...
              </p>
            </div>
          </div>
        )}

        {feedbackData && (
          <div className="animate-fadeIn">
            <div className="mb-8 p-4 bg-primary-50 rounded-lg">
              <div className="flex items-center mb-2">
                <Award className="w-6 h-6 text-primary-600 mr-2" />
                <h3 className="text-xl font-semibold">Overall Performance</h3>
              </div>
              <div className="flex items-center mb-3">
                <div className="flex-grow">
                  <div className="h-2 bg-gray-200 rounded-full">
                    <div 
                      className="h-2 bg-primary-500 rounded-full" 
                      style={{ width: `${feedbackData.overall.score * 10}%` }}
                    ></div>
                  </div>
                </div>
                <span className="ml-4 font-semibold text-lg">
                  {feedbackData.overall.score}/10
                </span>
              </div>
              <p className="text-gray-700">{feedbackData.overall.summary}</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {['clarity', 'specificity', 'confidence'].map((category) => {
                const data = feedbackData[category as keyof typeof feedbackData] as FeedbackScore;
                return (
                  <div key={category} className="card border border-gray-100">
                    <h3 className="text-lg font-semibold mb-3 capitalize">{category}</h3>
                    
                    <div className="flex items-center mb-3">
                      <div className="flex-grow">
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className={`h-2 rounded-full ${
                              data.score >= 8 ? 'bg-success-500' : 
                              data.score >= 5 ? 'bg-warning-500' : 
                              'bg-error-500'
                            }`}
                            style={{ width: `${data.score * 10}%` }}
                          ></div>
                        </div>
                      </div>
                      <span className="ml-4 font-semibold">
                        {data.score}/10
                      </span>
                    </div>
                    
                    <p className="text-sm text-gray-700 mb-4">{data.summary}</p>
                    
                    {data.suggestions.length > 0 && (
                      <div>
                        <h4 className="text-sm font-semibold mb-2">Suggestions:</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          {data.suggestions.map((suggestion, i) => (
                            <li key={i} className="flex">
                              <Check className="h-4 w-4 text-success-500 mr-2 flex-shrink-0 mt-0.5" />
                              <span>{suggestion}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">Interview Transcript</h3>
              <div className="p-4 bg-gray-50 rounded-lg text-sm text-gray-700 whitespace-pre-line">
                {interview.transcript}
              </div>
            </div>

            <div className="flex justify-end">
              <Button 
                variant="primary" 
                onClick={handleGoToDebrief}
                leftIcon={<BookOpenCheck className="h-5 w-5" />}
              >
                Complete Post-Interview Debrief
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FeedbackPage;