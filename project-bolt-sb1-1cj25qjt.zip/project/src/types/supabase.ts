export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      interviews: {
        Row: {
          id: string
          created_at: string
          full_name: string
          phone_number: string
          linkedin_url: string | null
          role: string
          company: string
          job_posting_url: string
          interview_stage: string
          interview_date: string
          interviewer_name: string | null
          transcript: string | null
          feedback: Json | null
          status: 'pending' | 'completed' | 'scheduled'
        }
        Insert: {
          id?: string
          created_at?: string
          full_name: string
          phone_number: string
          linkedin_url?: string | null
          role: string
          company: string
          job_posting_url: string
          interview_stage: string
          interview_date: string
          interviewer_name?: string | null
          transcript?: string | null
          feedback?: Json | null
          status?: 'pending' | 'completed' | 'scheduled'
        }
        Update: {
          id?: string
          created_at?: string
          full_name?: string
          phone_number?: string
          linkedin_url?: string | null
          role?: string
          company?: string
          job_posting_url?: string
          interview_stage?: string
          interview_date?: string
          interviewer_name?: string | null
          transcript?: string | null
          feedback?: Json | null
          status?: 'pending' | 'completed' | 'scheduled'
        }
      }
      debriefs: {
        Row: {
          id: string
          created_at: string
          interview_id: string
          rating: number
          actual_questions: string[]
          notes: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          interview_id: string
          rating: number
          actual_questions: string[]
          notes?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          interview_id?: string
          rating?: number
          actual_questions?: string[]
          notes?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}