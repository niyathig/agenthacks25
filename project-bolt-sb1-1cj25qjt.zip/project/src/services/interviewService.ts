import { useSupabase } from '../contexts/SupabaseContext';

interface InitiateInterviewParams {
  interviewId: string;
  phoneNumber: string;
  role: string;
  company: string;
}

export const initiateInterview = async ({
  interviewId,
  phoneNumber,
  role,
  company,
}: InitiateInterviewParams) => {
  try {
    // This would be replaced with an actual API call to Leaping AI
    // For now, we'll simulate the response
    
    console.log(`Initiating interview for ${interviewId} at ${phoneNumber}`);
    
    // Simulate API call to Leaping AI
    const response = await fetch('/api/initiate-interview', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        interviewId,
        phoneNumber,
        role,
        company,
      }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to initiate interview');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error initiating interview:', error);
    throw error;
  }
};

export const updateInterviewTranscript = async (interviewId: string, transcript: string) => {
  const { supabase } = useSupabase();
  
  try {
    const { error } = await supabase
      .from('interviews')
      .update({
        transcript,
        status: 'completed',
      })
      .eq('id', interviewId);
      
    if (error) {
      throw error;
    }
  } catch (error) {
    console.error('Error updating transcript:', error);
    throw error;
  }
};

export const generateFeedback = async (interviewId: string, transcript: string) => {
  try {
    // This would call an LLM service to analyze the transcript
    // For now, we'll simulate the response
    
    // Simulate API call to LLM service
    const response = await fetch('/api/analyze-transcript', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        transcript,
      }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to generate feedback');
    }
    
    const feedback = await response.json();
    
    const { supabase } = useSupabase();
    
    // Update feedback in database
    const { error } = await supabase
      .from('interviews')
      .update({
        feedback,
      })
      .eq('id', interviewId);
      
    if (error) {
      throw error;
    }
    
    return feedback;
  } catch (error) {
    console.error('Error generating feedback:', error);
    throw error;
  }
};