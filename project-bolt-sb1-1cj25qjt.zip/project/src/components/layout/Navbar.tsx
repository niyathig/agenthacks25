import React from 'react';
import { Link } from 'react-router-dom';
import { Pen, Briefcase as BriefcaseBusiness } from 'lucide-react';

const Navbar: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <BriefcaseBusiness className="h-8 w-8 text-primary-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">PrepWise</span>
            </Link>
          </div>
          <div className="flex items-center">
            <Link 
              to="/intake" 
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
            >
              <Pen className="h-4 w-4 mr-1" />
              New Interview
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;