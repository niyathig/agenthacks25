// This would be an edge function to analyze interview transcripts

import { serve } from "http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  // Only accept POST requests
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    // Parse the request body
    const body = await req.json();
    const { transcript } = body;

    // In a real implementation, this would use an LLM to analyze the transcript
    // For now, we'll return mock feedback data

    // Generate mock feedback data
    const feedback = {
      clarity: {
        score: 8,
        summary: "Your responses were generally clear and well-structured, with good use of specific examples and data points.",
        suggestions: [
          "Consider using more transitional phrases to connect your main points",
          "Try summarizing your key achievements at the end of longer answers"
        ]
      },
      specificity: {
        score: 9,
        summary: "You provided excellent specific examples with quantifiable results and clear context.",
        suggestions: [
          "Continue using metrics and percentages to illustrate your impact"
        ]
      },
      confidence: {
        score: 7,
        summary: "Your delivery showed good confidence, though there were a few moments of hesitation when discussing technical challenges.",
        suggestions: [
          "Practice speaking about technical concepts with more assertiveness",
          "Reduce filler words like 'um' and 'you know' for more authoritative delivery",
          "Maintain consistent pace throughout your responses"
        ]
      },
      overall: {
        score: 8,
        summary: "Overall, you demonstrated strong interview skills with clear communication, specific examples, and good confidence. Your responses to the project question and conflict resolution question were particularly effective, showing both technical expertise and interpersonal skills. With a few adjustments to delivery and structure, you'll be even more impressive in your actual interview."
      }
    };

    // Return the feedback
    return new Response(
      JSON.stringify(feedback), 
      { 
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  } catch (error) {
    console.error("Error analyzing transcript:", error);
    
    return new Response(
      JSON.stringify({ error: "Failed to analyze transcript" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});