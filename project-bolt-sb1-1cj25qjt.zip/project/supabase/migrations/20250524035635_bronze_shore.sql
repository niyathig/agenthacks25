/*
  # Initial Database Schema for PrepWise

  1. New Tables
    - `interviews`
      - Stores all interview preparation data
      - Includes personal info, job details, and interview status
      - Contains transcript and feedback data
    - `debriefs`
      - Stores post-interview feedback
      - Links to interviews table
      - Includes rating, actual questions, and notes

  2. Security
    - Enable RLS on all tables
    - Add public read/write policies (simplified for MVP)
*/

-- Create interviews table
CREATE TABLE IF NOT EXISTS interviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  full_name text NOT NULL,
  phone_number text NOT NULL,
  linkedin_url text,
  role text NOT NULL,
  company text NOT NULL,
  job_posting_url text NOT NULL,
  interview_stage text NOT NULL,
  interview_date date NOT NULL,
  interviewer_name text,
  transcript text,
  feedback jsonb,
  status text NOT NULL DEFAULT 'pending'
);

-- Create debriefs table
CREATE TABLE IF NOT EXISTS debriefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  interview_id uuid REFERENCES interviews(id) NOT NULL,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  actual_questions text[] NOT NULL,
  notes text
);

-- Enable RLS
ALTER TABLE interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE debriefs ENABLE ROW LEVEL SECURITY;

-- Add policies (simplified for MVP)
CREATE POLICY "Public access to interviews"
  ON interviews
  FOR ALL
  USING (true);

CREATE POLICY "Public access to debriefs"
  ON debriefs
  FOR ALL
  USING (true);